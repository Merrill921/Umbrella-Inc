/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : teaching_platform

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 12/02/2025 22:13:31
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for apply
-- ----------------------------
DROP TABLE IF EXISTS `apply`;
CREATE TABLE `apply`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` int NULL DEFAULT NULL COMMENT '学生ID',
  `course_id` int NULL DEFAULT NULL COMMENT '课程ID',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '申请说明',
  `process` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '当前进度',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '审核状态',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '审核说明',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '申请审批表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of apply
-- ----------------------------
INSERT INTO `apply` VALUES (8, 3, 17, '我爱学习', '审核完成', '审核通过', '通过审核');
INSERT INTO `apply` VALUES (14, 2, 14, '我爱语文', '审核完成', '审核通过', '允许学习');

-- ----------------------------
-- Table structure for banner
-- ----------------------------
DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '轮播备注',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '轮播图',
  `link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '跳转链接',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of banner
-- ----------------------------
INSERT INTO `banner` VALUES (11, '这是百度的logo', 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'www.baidu.com');
INSERT INTO `banner` VALUES (12, 'b站地址', 'http://localhost:9090/file/58452f19443341e98dd60f11cbb47de8.jpg', 'https://www.bilibili.com/');
INSERT INTO `banner` VALUES (13, '抖音地址', 'http://localhost:9090/file/26789e7fcbf04e31bb7066df0179a7c1.jpeg', 'https://www.douyin.com/');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` int NULL DEFAULT NULL COMMENT '学生ID',
  `course_id` int NULL DEFAULT NULL COMMENT '课程ID',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '评论时间',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '评论内容',
  `parent_id` int NULL DEFAULT NULL COMMENT '父ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 43 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '评论信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES (29, 3, 14, '2024-09-10 22:41:02', '111', 0);
INSERT INTO `comment` VALUES (30, 3, 14, '2024-09-10 22:41:04', '222', 0);
INSERT INTO `comment` VALUES (31, 3, 14, '2024-09-10 22:41:25', '333', 29);
INSERT INTO `comment` VALUES (32, 3, 14, '2024-09-10 22:41:40', '444', 29);
INSERT INTO `comment` VALUES (33, 3, 14, '2024-09-10 23:10:41', '555', 30);
INSERT INTO `comment` VALUES (34, 3, 14, '2024-09-10 23:10:45', '666', 30);
INSERT INTO `comment` VALUES (35, 3, 14, '2024-09-10 23:17:04', '777', 29);
INSERT INTO `comment` VALUES (36, 2, 14, '2024-09-10 23:17:42', '888', 30);
INSERT INTO `comment` VALUES (37, 2, 14, '2024-09-10 23:17:57', '999', 0);
INSERT INTO `comment` VALUES (38, 3, 14, '2024-09-11 11:20:21', '101010', 37);
INSERT INTO `comment` VALUES (39, 3, 14, '2024-09-11 11:21:14', '11 11 11', 0);
INSERT INTO `comment` VALUES (40, 2, 14, '2024-09-11 11:22:21', '12 12 12', 39);
INSERT INTO `comment` VALUES (41, 2, 14, '2024-09-11 11:22:31', '13 13 13', 0);
INSERT INTO `comment` VALUES (42, 3, 14, '2024-09-11 20:37:26', '14 14 14', 39);
INSERT INTO `comment` VALUES (43, 3, 17, '2024-09-11 20:37:48', '21 21 21', 0);

-- ----------------------------
-- Table structure for comments
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名称',
  `user_id` int NULL DEFAULT NULL COMMENT '用户id',
  `rate` decimal(10, 1) NULL DEFAULT NULL COMMENT '评分',
  `foreign_id` int NULL DEFAULT NULL COMMENT '业务模块的id',
  `pid` int NULL DEFAULT NULL COMMENT '父级评论id',
  `target` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '回复对象',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户头像',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '讨论信息表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of comments
-- ----------------------------

-- ----------------------------
-- Table structure for consulting
-- ----------------------------
DROP TABLE IF EXISTS `consulting`;
CREATE TABLE `consulting`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标题名称',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '图片',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '发布时间',
  `user_id` int NULL DEFAULT NULL COMMENT '发布人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 22 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '资讯信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of consulting
-- ----------------------------
INSERT INTO `consulting` VALUES (1, '校园养犬事件', 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '最近有同学在宿色养小动物', '2024-09-12 11:32:07', 1);
INSERT INTO `consulting` VALUES (2, '111', 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '<p>111</p>', '2024-09-12 12:10:52', 1);
INSERT INTO `consulting` VALUES (21, '111', 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', '<p>222</p><p><br></p><p><img src=\"http://localhost:9090/file/11df8359e2b246a982d4cf7e32c3e563.jpeg\" alt=\"\" data-href=\"\" style=\"\"/></p>', '2024-09-12 17:40:35', 1);

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '课程名称',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '课程图片',
  `describes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '课程描述',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '课程类型',
  `teacher_id` int NULL DEFAULT NULL COMMENT '授课教师id',
  `num` bigint NULL DEFAULT NULL COMMENT '数量',
  `user_id` int NULL DEFAULT NULL COMMENT '学生id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 18 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '课程管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES (14, '语文', 'http://localhost:9090/file/a983f2a0a32d4ada989447d61f7b0319.jpeg', '了解历史', '必修', 5, 45, NULL);
INSERT INTO `course` VALUES (15, '数学', 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', '搬砖专业', '必修', 4, 30, NULL);
INSERT INTO `course` VALUES (16, '计算机与科学', 'http://localhost:9090/file/d2b60251dd6a4a808182dd49ecb146d7.jpg', '了解计算机的运用以及历史', '选修', 4, 30, NULL);
INSERT INTO `course` VALUES (17, '人与自然', 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '讲述人与自然环境的变化', '选修', 5, 35, NULL);

-- ----------------------------
-- Table structure for exam
-- ----------------------------
DROP TABLE IF EXISTS `exam`;
CREATE TABLE `exam`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '封面图',
  `start_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '结束时间',
  `question` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '试题列表',
  `score` int NULL DEFAULT NULL COMMENT '考试总分',
  `user_id` int NULL DEFAULT NULL COMMENT '用户id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '考试标题',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '考试信息管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of exam
-- ----------------------------
INSERT INTO `exam` VALUES (9, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '2024-09-09 20:34:01', '2024-09-30 00:00:00', '12,13,14,15,16,17,18,19,20,21', 100, NULL, '期中考试');
INSERT INTO `exam` VALUES (10, 'http://localhost:9090/file/26789e7fcbf04e31bb7066df0179a7c1.jpeg', '2024-09-10 11:13:24', '2024-09-30 00:00:00', '12,13,14,15,16,17,18,19,20,21', 100, 5, '期末考试');
INSERT INTO `exam` VALUES (11, 'http://localhost:9090/file/a983f2a0a32d4ada989447d61f7b0319.jpeg', '2024-09-10 11:19:14', '2024-09-30 00:00:00', '12,13,14,15,16,17,18,19,20,21', 100, 4, '毕业考试');

-- ----------------------------
-- Table structure for exam_question
-- ----------------------------
DROP TABLE IF EXISTS `exam_question`;
CREATE TABLE `exam_question`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '题目',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '题型',
  `options` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '选择题选项',
  `answer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '正确答案',
  `score` int NULL DEFAULT NULL COMMENT '分值',
  `user_id` int NULL DEFAULT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 22 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '试题信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of exam_question
-- ----------------------------
INSERT INTO `exam_question` VALUES (12, '\"1\" + \"1\"', '多选题', '[\"A：2\",\"B：3\",\"C：11\",\"D：22\"]', 'C', 10, NULL);
INSERT INTO `exam_question` VALUES (13, '2*2', '单选题', '[\"A：2\",\"B：8\",\"C：22\",\"D：44\"]', 'A', 10, NULL);
INSERT INTO `exam_question` VALUES (14, '下列选项中，不属于HTML结构标签的是？', '单选题', '[\"A：DOCTYPE\",\"B：html\",\"C：title\",\"D：div\"]', 'D', 10, NULL);
INSERT INTO `exam_question` VALUES (15, '‌在JavaScript中，下列哪个选项不是数组方法？', '单选题', '[\"A：sort()\",\"B：length()\",\"C：concat()\",\"D：reverse()\"]', 'B', 10, NULL);
INSERT INTO `exam_question` VALUES (16, '在HTML中，哪个标签用来定义图片的源路径？', '单选题', '[\"A：<img src=”../image/img.gif” />\",\"B： <img src=”image/img.gif” />\",\"C：<img src=”image../img.gif” />\",\"D：<img src=”img.gif/image” />\"]', 'A', 10, NULL);
INSERT INTO `exam_question` VALUES (17, '在CSS中，哪个属性可以用来控制元素的盒模型？', '单选题', '[\"A：box-sizing\",\"B：box-shadow\",\"C：box-flex\",\"D：box-pack\"]', 'A', 10, NULL);
INSERT INTO `exam_question` VALUES (18, '‌表达式1010 == 0x3F0的结果是==True', '判断题', NULL, 'true', 10, NULL);
INSERT INTO `exam_question` VALUES (19, '判断题5!=4输出结果是False', '判断题', NULL, 'true', 10, NULL);
INSERT INTO `exam_question` VALUES (20, '‌JavaScript声明变量的语句是var a=1;', '判断题', NULL, 'true', 10, NULL);
INSERT INTO `exam_question` VALUES (21, '‌文件头标签也就是通常所见到的_标题', '填空题', NULL, '<head>', 10, NULL);

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标题',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建时间',
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '公告信息表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (1, '今天系统正式上线，开始内测', '今天系统正式上线，开始内测', '2024-04-11', 'admin');
INSERT INTO `notice` VALUES (2, '所有功能都已完成，可以正常使用', '所有功能都已完成，可以正常使用', '2024-04-11', 'admin');
INSERT INTO `notice` VALUES (3, '今天天气很不错，可以出去一起玩了', '今天天气很不错，可以出去一起玩了', '2024-04-11', 'admin');

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int NULL DEFAULT NULL COMMENT '用户id',
  `exam_id` int NULL DEFAULT NULL COMMENT '考试id',
  `teacher_id` int NULL DEFAULT NULL COMMENT '老师id',
  `score` int NULL DEFAULT NULL COMMENT '分数',
  `user_answers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '用户答案',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '考试名称',
  `ids` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '题目ids',
  `is_score` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '是否评分',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of score
-- ----------------------------
INSERT INTO `score` VALUES (8, 3, 9, NULL, 60, '[{\"id\":13,\"name\":\"2*2\",\"type\":\"单选题\",\"options\":[\"A：2\",\"B：8\",\"C：22\",\"D：44\"],\"answer\":\"A\",\"score\":10,\"userId\":null,\"userScore\":10,\"userAnswers\":\"A\"},{\"id\":14,\"name\":\"下列选项中，不属于HTML结构标签的是？\",\"type\":\"单选题\",\"options\":[\"A：DOCTYPE\",\"B：html\",\"C：title\",\"D：div\"],\"answer\":\"D\",\"score\":10,\"userId\":null,\"userScore\":10,\"userAnswers\":\"D\"},{\"id\":15,\"name\":\"‌在JavaScript中，下列哪个选项不是数组方法？\",\"type\":\"单选题\",\"options\":[\"A：sort()\",\"B：length()\",\"C：concat()\",\"D：reverse()\"],\"answer\":\"B\",\"score\":10,\"userId\":null,\"userScore\":0,\"userAnswers\":\"D\"},{\"id\":16,\"name\":\"在HTML中，哪个标签用来定义图片的源路径？\",\"type\":\"单选题\",\"options\":[\"A：<img src=”../image/img.gif” />\",\"B： <img src=”image/img.gif” />\",\"C：<img src=”image../img.gif” />\",\"D：<img src=”img.gif/image” />\"],\"answer\":\"A\",\"score\":10,\"userId\":null,\"userScore\":10,\"userAnswers\":\"A\"},{\"id\":17,\"name\":\"在CSS中，哪个属性可以用来控制元素的盒模型？\",\"type\":\"单选题\",\"options\":[\"A：box-sizing\",\"B：box-shadow\",\"C：box-flex\",\"D：box-pack\"],\"answer\":\"A\",\"score\":10,\"userId\":null,\"userScore\":10,\"userAnswers\":\"A\"},{\"id\":12,\"name\":\"\\\"1\\\" + \\\"1\\\"\",\"type\":\"多选题\",\"options\":[\"A：2\",\"B：3\",\"C：11\",\"D：22\"],\"answer\":\"C\",\"score\":10,\"userId\":null,\"userAnswers\":[\"C\"],\"userScore\":10},{\"id\":18,\"name\":\"‌表达式1010 == 0x3F0的结果是==True\",\"type\":\"判断题\",\"options\":null,\"answer\":\"true\",\"score\":10,\"userId\":null,\"userScore\":0,\"userAnswers\":\"对\"},{\"id\":19,\"name\":\"判断题5!=4输出结果是False\",\"type\":\"判断题\",\"options\":null,\"answer\":\"true\",\"score\":10,\"userId\":null,\"userScore\":0,\"userAnswers\":\"对\"},{\"id\":20,\"name\":\"‌JavaScript声明变量的语句是var a=1;\",\"type\":\"判断题\",\"options\":null,\"answer\":\"true\",\"score\":10,\"userId\":null,\"userScore\":0,\"userAnswers\":\"对\"},{\"id\":21,\"name\":\"‌文件头标签也就是通常所见到的_标题\",\"type\":\"填空题\",\"options\":null,\"answer\":\"<head>\",\"score\":10,\"userId\":null,\"userAnswers\":\"<head>\",\"userScore\":10}]', '期中考试', '12,13,14,15,16,17,18,19,20,21', '已评分');

-- ----------------------------
-- Table structure for sys_dict
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict`;
CREATE TABLE `sys_dict`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '类型',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 280 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_dict
-- ----------------------------
INSERT INTO `sys_dict` VALUES (1, 'user', 'el-icon-user', 'icon');
INSERT INTO `sys_dict` VALUES (2, 'house', 'el-icon-house', 'icon');
INSERT INTO `sys_dict` VALUES (3, 'menu', 'el-icon-menu', 'icon');
INSERT INTO `sys_dict` VALUES (4, 's-custom', 'el-icon-s-custom', 'icon');
INSERT INTO `sys_dict` VALUES (5, 's-grid', 'el-icon-s-grid', 'icon');
INSERT INTO `sys_dict` VALUES (6, 'document', 'el-icon-document', 'icon');
INSERT INTO `sys_dict` VALUES (7, 'coffee', 'el-icon-coffee\r\n', 'icon');
INSERT INTO `sys_dict` VALUES (8, 's-marketing', 'el-icon-s-marketing', 'icon');
INSERT INTO `sys_dict` VALUES (9, 'phone-outline', 'el-icon-phone-outline', 'icon');
INSERT INTO `sys_dict` VALUES (10, 'platform-eleme', 'el-icon-platform-eleme', 'icon');
INSERT INTO `sys_dict` VALUES (11, 'eleme', 'el-icon-eleme', 'icon');
INSERT INTO `sys_dict` VALUES (12, 'delete-solid', 'el-icon-delete-solid', 'icon');
INSERT INTO `sys_dict` VALUES (13, 'delete', 'el-icon-delete', 'icon');
INSERT INTO `sys_dict` VALUES (14, 's-tools', 'el-icon-s-tools', 'icon');
INSERT INTO `sys_dict` VALUES (15, 'setting', 'el-icon-setting', 'icon');
INSERT INTO `sys_dict` VALUES (16, 'user-solid', 'el-icon-user-solid', 'icon');
INSERT INTO `sys_dict` VALUES (17, 'phone', 'el-icon-phone', 'icon');
INSERT INTO `sys_dict` VALUES (18, 'more', 'el-icon-more', 'icon');
INSERT INTO `sys_dict` VALUES (19, 'more-outline', 'el-icon-more-outline', 'icon');
INSERT INTO `sys_dict` VALUES (20, 'star-on', 'el-icon-star-on', 'icon');
INSERT INTO `sys_dict` VALUES (21, 'star-off', 'el-icon-star-off', 'icon');
INSERT INTO `sys_dict` VALUES (22, 's-goods', 'el-icon-s-goods', 'icon');
INSERT INTO `sys_dict` VALUES (23, 'goods', 'el-icon-goods', 'icon');
INSERT INTO `sys_dict` VALUES (24, 'warning', 'el-icon-warning', 'icon');
INSERT INTO `sys_dict` VALUES (25, 'warning-outline', 'el-icon-warning-outline', 'icon');
INSERT INTO `sys_dict` VALUES (26, 'question', 'el-icon-question', 'icon');
INSERT INTO `sys_dict` VALUES (27, 'info', 'el-icon-info', 'icon');
INSERT INTO `sys_dict` VALUES (28, 'remove', 'el-icon-remove', 'icon');
INSERT INTO `sys_dict` VALUES (29, 'circle-plus', 'el-icon-circle-plus', 'icon');
INSERT INTO `sys_dict` VALUES (30, 'success', 'el-icon-success', 'icon');
INSERT INTO `sys_dict` VALUES (31, 'error', 'el-icon-error', 'icon');
INSERT INTO `sys_dict` VALUES (32, 'zoom-in', 'el-icon-zoom-in', 'icon');
INSERT INTO `sys_dict` VALUES (33, 'zoom-out', 'el-icon-zoom-out', 'icon');
INSERT INTO `sys_dict` VALUES (34, 'remove-outline', 'el-icon-remove-outline', 'icon');
INSERT INTO `sys_dict` VALUES (35, 'circle-plus-outline', 'el-icon-circle-plus-outline', 'icon');
INSERT INTO `sys_dict` VALUES (36, 'circle-check', 'el-icon-circle-check', 'icon');
INSERT INTO `sys_dict` VALUES (37, 'circle-close', 'el-icon-circle-close', 'icon');
INSERT INTO `sys_dict` VALUES (38, 's-help', 'el-icon-s-help', 'icon');
INSERT INTO `sys_dict` VALUES (39, 'help', 'el-icon-help', 'icon');
INSERT INTO `sys_dict` VALUES (40, 'minus', 'el-icon-minus', 'icon');
INSERT INTO `sys_dict` VALUES (41, 'plus', 'el-icon-plus', 'icon');
INSERT INTO `sys_dict` VALUES (42, 'check', 'el-icon-check', 'icon');
INSERT INTO `sys_dict` VALUES (43, 'close', 'el-icon-close', 'icon');
INSERT INTO `sys_dict` VALUES (44, 'picture', 'el-icon-picture', 'icon');
INSERT INTO `sys_dict` VALUES (45, 'picture-outline', 'el-icon-picture-outline', 'icon');
INSERT INTO `sys_dict` VALUES (46, 'picture-outline-round', 'el-icon-picture-outline-round', 'icon');
INSERT INTO `sys_dict` VALUES (47, 'upload', 'el-icon-upload', 'icon');
INSERT INTO `sys_dict` VALUES (48, 'upload2', 'el-icon-upload2', 'icon');
INSERT INTO `sys_dict` VALUES (49, 'download', 'el-icon-download', 'icon');
INSERT INTO `sys_dict` VALUES (50, 'camera-solid', 'el-icon-camera-solid', 'icon');
INSERT INTO `sys_dict` VALUES (51, 'camera', 'el-icon-camera', 'icon');
INSERT INTO `sys_dict` VALUES (52, 'video-camera-solid', 'el-icon-video-camera-solid', 'icon');
INSERT INTO `sys_dict` VALUES (53, 'video-camera', 'el-icon-video-camera', 'icon');
INSERT INTO `sys_dict` VALUES (54, 'message-solid', 'el-icon-message-solid', 'icon');
INSERT INTO `sys_dict` VALUES (55, 'bell', 'el-icon-bell', 'icon');
INSERT INTO `sys_dict` VALUES (56, 's-cooperation', 'el-icon-s-cooperation', 'icon');
INSERT INTO `sys_dict` VALUES (57, 's-order', 'el-icon-s-order', 'icon');
INSERT INTO `sys_dict` VALUES (58, 's-platform', 'el-icon-s-platform', 'icon');
INSERT INTO `sys_dict` VALUES (59, 's-fold', 'el-icon-s-fold', 'icon');
INSERT INTO `sys_dict` VALUES (60, 's-unfold', 'el-icon-s-unfold', 'icon');
INSERT INTO `sys_dict` VALUES (61, 's-operation', 'el-icon-s-operation', 'icon');
INSERT INTO `sys_dict` VALUES (62, 's-promotion', 'el-icon-s-promotion', 'icon');
INSERT INTO `sys_dict` VALUES (63, 's-home', 'el-icon-s-home', 'icon');
INSERT INTO `sys_dict` VALUES (64, 's-release', 'el-icon-s-release', 'icon');
INSERT INTO `sys_dict` VALUES (65, 's-ticket', 'el-icon-s-ticket', 'icon');
INSERT INTO `sys_dict` VALUES (66, 's-management', 'el-icon-s-management', 'icon');
INSERT INTO `sys_dict` VALUES (67, 's-open', 'el-icon-s-open', 'icon');
INSERT INTO `sys_dict` VALUES (68, 's-shop', 'el-icon-s-shop', 'icon');
INSERT INTO `sys_dict` VALUES (69, 's-flag', 'el-icon-s-flag', 'icon');
INSERT INTO `sys_dict` VALUES (70, 's-comment', 'el-icon-s-comment', 'icon');
INSERT INTO `sys_dict` VALUES (71, 's-finance', 'el-icon-s-finance', 'icon');
INSERT INTO `sys_dict` VALUES (72, 's-claim', 'el-icon-s-claim', 'icon');
INSERT INTO `sys_dict` VALUES (73, 's-opportunity', 'el-icon-s-opportunity', 'icon');
INSERT INTO `sys_dict` VALUES (74, 's-data', 'el-icon-s-data', 'icon');
INSERT INTO `sys_dict` VALUES (75, 's-check', 'el-icon-s-check', 'icon');
INSERT INTO `sys_dict` VALUES (76, 'share', 'el-icon-share', 'icon');
INSERT INTO `sys_dict` VALUES (77, 'd-caret', 'el-icon-d-caret', 'icon');
INSERT INTO `sys_dict` VALUES (78, 'caret-left', 'el-icon-caret-left', 'icon');
INSERT INTO `sys_dict` VALUES (79, 'caret-right', 'el-icon-caret-right', 'icon');
INSERT INTO `sys_dict` VALUES (80, 'caret-bottom', 'el-icon-caret-bottom', 'icon');
INSERT INTO `sys_dict` VALUES (81, 'caret-top', 'el-icon-caret-top', 'icon');
INSERT INTO `sys_dict` VALUES (82, 'bottom-left', 'el-icon-bottom-left', 'icon');
INSERT INTO `sys_dict` VALUES (83, 'bottom-right', 'el-icon-bottom-right', 'icon');
INSERT INTO `sys_dict` VALUES (84, 'back', 'el-icon-back', 'icon');
INSERT INTO `sys_dict` VALUES (85, 'right', 'el-icon-right', 'icon');
INSERT INTO `sys_dict` VALUES (86, 'bottom', 'el-icon-bottom', 'icon');
INSERT INTO `sys_dict` VALUES (87, 'top', 'el-icon-top', 'icon');
INSERT INTO `sys_dict` VALUES (88, 'top-left', 'el-icon-top-left', 'icon');
INSERT INTO `sys_dict` VALUES (89, 'top-right', 'el-icon-top-right', 'icon');
INSERT INTO `sys_dict` VALUES (90, 'arrow-left', 'el-icon-arrow-left', 'icon');
INSERT INTO `sys_dict` VALUES (91, 'arrow-right', 'el-icon-arrow-right', 'icon');
INSERT INTO `sys_dict` VALUES (92, 'arrow-down', 'el-icon-arrow-down', 'icon');
INSERT INTO `sys_dict` VALUES (93, 'arrow-up', 'el-icon-arrow-up', 'icon');
INSERT INTO `sys_dict` VALUES (94, 'd-arrow-left', 'el-icon-d-arrow-left', 'icon');
INSERT INTO `sys_dict` VALUES (95, 'd-arrow-right', 'el-icon-d-arrow-right', 'icon');
INSERT INTO `sys_dict` VALUES (96, 'video-pause', 'el-icon-video-pause', 'icon');
INSERT INTO `sys_dict` VALUES (97, 'video-play', 'el-icon-video-play', 'icon');
INSERT INTO `sys_dict` VALUES (98, 'refresh', 'el-icon-refresh', 'icon');
INSERT INTO `sys_dict` VALUES (99, 'refresh-right', 'el-icon-refresh-right', 'icon');
INSERT INTO `sys_dict` VALUES (100, 'refresh-left', 'el-icon-refresh-left', 'icon');
INSERT INTO `sys_dict` VALUES (101, 'finished', 'el-icon-finished', 'icon');
INSERT INTO `sys_dict` VALUES (102, 'sort', 'el-icon-sort', 'icon');
INSERT INTO `sys_dict` VALUES (103, 'sort-up', 'el-icon-sort-up', 'icon');
INSERT INTO `sys_dict` VALUES (104, 'sort-down', 'el-icon-sort-down', 'icon');
INSERT INTO `sys_dict` VALUES (105, 'rank', 'el-icon-rank', 'icon');
INSERT INTO `sys_dict` VALUES (106, 'loading', 'el-icon-loading', 'icon');
INSERT INTO `sys_dict` VALUES (107, 'view', 'el-icon-view', 'icon');
INSERT INTO `sys_dict` VALUES (108, 'c-scale-to-original', 'el-icon-c-scale-to-original', 'icon');
INSERT INTO `sys_dict` VALUES (109, 'date', 'el-icon-date', 'icon');
INSERT INTO `sys_dict` VALUES (110, 'edit', 'el-icon-edit', 'icon');
INSERT INTO `sys_dict` VALUES (111, 'edit-outline', 'el-icon-edit-outline', 'icon');
INSERT INTO `sys_dict` VALUES (112, 'folder', 'el-icon-folder', 'icon');
INSERT INTO `sys_dict` VALUES (113, 'folder-opened', 'el-icon-folder-opened', 'icon');
INSERT INTO `sys_dict` VALUES (114, 'folder-add', 'el-icon-folder-add', 'icon');
INSERT INTO `sys_dict` VALUES (115, 'folder-remove', 'el-icon-folder-remove', 'icon');
INSERT INTO `sys_dict` VALUES (116, 'folder-delete', 'el-icon-folder-delete', 'icon');
INSERT INTO `sys_dict` VALUES (117, 'folder-checked', 'el-icon-folder-checked', 'icon');
INSERT INTO `sys_dict` VALUES (118, 'tickets', 'el-icon-tickets', 'icon');
INSERT INTO `sys_dict` VALUES (119, 'document-remove', 'el-icon-document-remove', 'icon');
INSERT INTO `sys_dict` VALUES (120, 'document-delete', 'el-icon-document-delete', 'icon');
INSERT INTO `sys_dict` VALUES (121, 'document-copy', 'el-icon-document-copy', 'icon');
INSERT INTO `sys_dict` VALUES (122, 'document-checked', 'el-icon-document-checked', 'icon');
INSERT INTO `sys_dict` VALUES (123, 'document-add', 'el-icon-document-add', 'icon');
INSERT INTO `sys_dict` VALUES (124, 'printer', 'el-icon-printer', 'icon');
INSERT INTO `sys_dict` VALUES (125, 'paperclip', 'el-icon-paperclip', 'icon');
INSERT INTO `sys_dict` VALUES (126, 'takeaway-box', 'el-icon-takeaway-box', 'icon');
INSERT INTO `sys_dict` VALUES (127, 'search', 'el-icon-search', 'icon');
INSERT INTO `sys_dict` VALUES (128, 'monitor', 'el-icon-monitor', 'icon');
INSERT INTO `sys_dict` VALUES (129, 'attract', 'el-icon-attract', 'icon');
INSERT INTO `sys_dict` VALUES (130, 'mobile', 'el-icon-mobile', 'icon');
INSERT INTO `sys_dict` VALUES (131, 'scissors', 'el-icon-scissors', 'icon');
INSERT INTO `sys_dict` VALUES (132, 'umbrella', 'el-icon-umbrella', 'icon');
INSERT INTO `sys_dict` VALUES (133, 'headset', 'el-icon-headset', 'icon');
INSERT INTO `sys_dict` VALUES (134, 'brush', 'el-icon-brush', 'icon');
INSERT INTO `sys_dict` VALUES (135, 'mouse', 'el-icon-mouse', 'icon');
INSERT INTO `sys_dict` VALUES (136, 'coordinate', 'el-icon-coordinate', 'icon');
INSERT INTO `sys_dict` VALUES (137, 'magic-stick', 'el-icon-magic-stick', 'icon');
INSERT INTO `sys_dict` VALUES (138, 'reading', 'el-icon-reading', 'icon');
INSERT INTO `sys_dict` VALUES (139, 'data-line', 'el-icon-data-line', 'icon');
INSERT INTO `sys_dict` VALUES (140, 'data-board', 'el-icon-data-board', 'icon');
INSERT INTO `sys_dict` VALUES (141, 'pie-chart', 'el-icon-pie-chart', 'icon');
INSERT INTO `sys_dict` VALUES (142, 'data-analysis', 'el-icon-data-analysis', 'icon');
INSERT INTO `sys_dict` VALUES (143, 'collection-tag', 'el-icon-collection-tag', 'icon');
INSERT INTO `sys_dict` VALUES (144, 'film', 'el-icon-film', 'icon');
INSERT INTO `sys_dict` VALUES (145, 'suitcase', 'el-icon-suitcase', 'icon');
INSERT INTO `sys_dict` VALUES (146, 'suitcase-1', 'el-icon-suitcase-1', 'icon');
INSERT INTO `sys_dict` VALUES (147, 'receiving', 'el-icon-receiving', 'icon');
INSERT INTO `sys_dict` VALUES (148, 'collection', 'el-icon-collection', 'icon');
INSERT INTO `sys_dict` VALUES (149, 'files', 'el-icon-files', 'icon');
INSERT INTO `sys_dict` VALUES (150, 'notebook-1', 'el-icon-notebook-1', 'icon');
INSERT INTO `sys_dict` VALUES (151, 'notebook-2', 'el-icon-notebook-2', 'icon');
INSERT INTO `sys_dict` VALUES (152, 'toilet-paper', 'el-icon-toilet-paper', 'icon');
INSERT INTO `sys_dict` VALUES (153, 'office-building', 'el-icon-office-building', 'icon');
INSERT INTO `sys_dict` VALUES (154, 'school', 'el-icon-school', 'icon');
INSERT INTO `sys_dict` VALUES (155, 'table-lamp', 'el-icon-table-lamp', 'icon');
INSERT INTO `sys_dict` VALUES (156, 'no-smoking', 'el-icon-no-smoking', 'icon');
INSERT INTO `sys_dict` VALUES (157, 'smoking', 'el-icon-smoking', 'icon');
INSERT INTO `sys_dict` VALUES (158, 'shopping-cart-full', 'el-icon-shopping-cart-full', 'icon');
INSERT INTO `sys_dict` VALUES (159, 'shopping-cart-1', 'el-icon-shopping-cart-1', 'icon');
INSERT INTO `sys_dict` VALUES (160, 'shopping-cart-2', 'el-icon-shopping-cart-2', 'icon');
INSERT INTO `sys_dict` VALUES (161, 'shopping-bag-1', 'el-icon-shopping-bag-1', 'icon');
INSERT INTO `sys_dict` VALUES (162, 'shopping-bag-2', 'el-icon-shopping-bag-2', 'icon');
INSERT INTO `sys_dict` VALUES (163, 'sold-out', 'el-icon-sold-out', 'icon');
INSERT INTO `sys_dict` VALUES (164, 'sell', 'el-icon-sell', 'icon');
INSERT INTO `sys_dict` VALUES (165, 'present', 'el-icon-present', 'icon');
INSERT INTO `sys_dict` VALUES (166, 'box', 'el-icon-box', 'icon');
INSERT INTO `sys_dict` VALUES (167, 'bank-card', 'el-icon-bank-card', 'icon');
INSERT INTO `sys_dict` VALUES (168, 'money', 'el-icon-money', 'icon');
INSERT INTO `sys_dict` VALUES (169, 'coin', 'el-icon-coin', 'icon');
INSERT INTO `sys_dict` VALUES (170, 'wallet', 'el-icon-wallet', 'icon');
INSERT INTO `sys_dict` VALUES (171, 'discount', 'el-icon-discount', 'icon');
INSERT INTO `sys_dict` VALUES (172, 'price-tag', 'el-icon-price-tag', 'icon');
INSERT INTO `sys_dict` VALUES (173, 'news', 'el-icon-news', 'icon');
INSERT INTO `sys_dict` VALUES (174, 'guide', 'el-icon-guide', 'icon');
INSERT INTO `sys_dict` VALUES (175, 'male', 'el-icon-male', 'icon');
INSERT INTO `sys_dict` VALUES (176, 'female', 'el-icon-female', 'icon');
INSERT INTO `sys_dict` VALUES (177, 'thumb', 'el-icon-thumb', 'icon');
INSERT INTO `sys_dict` VALUES (178, 'cpu', 'el-icon-cpu', 'icon');
INSERT INTO `sys_dict` VALUES (179, 'link', 'el-icon-link', 'icon');
INSERT INTO `sys_dict` VALUES (180, 'connection', 'el-icon-connection', 'icon');
INSERT INTO `sys_dict` VALUES (181, 'open', 'el-icon-open', 'icon');
INSERT INTO `sys_dict` VALUES (182, 'turn-off', 'el-icon-turn-off', 'icon');
INSERT INTO `sys_dict` VALUES (183, 'set-up', 'el-icon-set-up', 'icon');
INSERT INTO `sys_dict` VALUES (184, 'chat-round', 'el-icon-chat-round', 'icon');
INSERT INTO `sys_dict` VALUES (185, 'chat-line-round', 'el-icon-chat-line-round', 'icon');
INSERT INTO `sys_dict` VALUES (186, 'chat-square', 'el-icon-chat-square', 'icon');
INSERT INTO `sys_dict` VALUES (187, 'chat-dot-round', 'el-icon-chat-dot-round', 'icon');
INSERT INTO `sys_dict` VALUES (188, 'chat-dot-square', 'el-icon-chat-dot-square', 'icon');
INSERT INTO `sys_dict` VALUES (189, 'chat-line-square', 'el-icon-chat-line-square', 'icon');
INSERT INTO `sys_dict` VALUES (190, 'message', 'el-icon-message', 'icon');
INSERT INTO `sys_dict` VALUES (191, 'postcard', 'el-icon-postcard', 'icon');
INSERT INTO `sys_dict` VALUES (192, 'position', 'el-icon-position', 'icon');
INSERT INTO `sys_dict` VALUES (193, 'turn-off-microphone', 'el-icon-turn-off-microphone', 'icon');
INSERT INTO `sys_dict` VALUES (194, 'microphone', 'el-icon-microphone', 'icon');
INSERT INTO `sys_dict` VALUES (195, 'close-notification', 'el-icon-close-notification', 'icon');
INSERT INTO `sys_dict` VALUES (196, 'bangzhu', 'el-icon-bangzhu', 'icon');
INSERT INTO `sys_dict` VALUES (197, 'time', 'el-icon-time', 'icon');
INSERT INTO `sys_dict` VALUES (198, 'odometer', 'el-icon-odometer', 'icon');
INSERT INTO `sys_dict` VALUES (199, 'crop', 'el-icon-crop', 'icon');
INSERT INTO `sys_dict` VALUES (200, 'aim', 'el-icon-aim', 'icon');
INSERT INTO `sys_dict` VALUES (201, 'switch-button', 'el-icon-switch-button', 'icon');
INSERT INTO `sys_dict` VALUES (202, 'full-screen', 'el-icon-full-screen', 'icon');
INSERT INTO `sys_dict` VALUES (203, 'copy-document', 'el-icon-copy-document', 'icon');
INSERT INTO `sys_dict` VALUES (204, 'mic', 'el-icon-mic', 'icon');
INSERT INTO `sys_dict` VALUES (205, 'stopwatch', 'el-icon-stopwatch', 'icon');
INSERT INTO `sys_dict` VALUES (206, 'medal-1', 'el-icon-medal-1', 'icon');
INSERT INTO `sys_dict` VALUES (207, 'medal', 'el-icon-medal', 'icon');
INSERT INTO `sys_dict` VALUES (208, 'trophy', 'el-icon-trophy', 'icon');
INSERT INTO `sys_dict` VALUES (209, 'trophy-1', 'el-icon-trophy-1', 'icon');
INSERT INTO `sys_dict` VALUES (210, 'first-aid-kit', 'el-icon-first-aid-kit', 'icon');
INSERT INTO `sys_dict` VALUES (211, 'discover', 'el-icon-discover', 'icon');
INSERT INTO `sys_dict` VALUES (212, 'place', 'el-icon-place', 'icon');
INSERT INTO `sys_dict` VALUES (213, 'location', 'el-icon-location', 'icon');
INSERT INTO `sys_dict` VALUES (214, 'location-outline', 'el-icon-location-outline', 'icon');
INSERT INTO `sys_dict` VALUES (215, 'location-information', 'el-icon-location-information', 'icon');
INSERT INTO `sys_dict` VALUES (216, 'add-location', 'el-icon-add-location', 'icon');
INSERT INTO `sys_dict` VALUES (217, 'delete-location', 'el-icon-delete-location', 'icon');
INSERT INTO `sys_dict` VALUES (218, 'map-location', 'el-icon-map-location', 'icon');
INSERT INTO `sys_dict` VALUES (219, 'alarm-clock', 'el-icon-alarm-clock', 'icon');
INSERT INTO `sys_dict` VALUES (220, 'timer', 'el-icon-timer', 'icon');
INSERT INTO `sys_dict` VALUES (221, 'watch-1', 'el-icon-watch-1', 'icon');
INSERT INTO `sys_dict` VALUES (222, 'watch', 'el-icon-watch', 'icon');
INSERT INTO `sys_dict` VALUES (223, 'lock', 'el-icon-lock', 'icon');
INSERT INTO `sys_dict` VALUES (224, 'unlock', 'el-icon-unlock', 'icon');
INSERT INTO `sys_dict` VALUES (225, 'key', 'el-icon-key', 'icon');
INSERT INTO `sys_dict` VALUES (226, 'service', 'el-icon-service', 'icon');
INSERT INTO `sys_dict` VALUES (227, 'mobile-phone', 'el-icon-mobile-phone', 'icon');
INSERT INTO `sys_dict` VALUES (228, 'bicycle', 'el-icon-bicycle', 'icon');
INSERT INTO `sys_dict` VALUES (229, 'truck', 'el-icon-truck', 'icon');
INSERT INTO `sys_dict` VALUES (230, 'ship', 'el-icon-ship', 'icon');
INSERT INTO `sys_dict` VALUES (231, 'basketball', 'el-icon-basketball', 'icon');
INSERT INTO `sys_dict` VALUES (232, 'football', 'el-icon-football', 'icon');
INSERT INTO `sys_dict` VALUES (233, 'soccer', 'el-icon-soccer', 'icon');
INSERT INTO `sys_dict` VALUES (234, 'baseball', 'el-icon-baseball', 'icon');
INSERT INTO `sys_dict` VALUES (235, 'wind-power', 'el-icon-wind-power', 'icon');
INSERT INTO `sys_dict` VALUES (236, 'light-rain', 'el-icon-light-rain', 'icon');
INSERT INTO `sys_dict` VALUES (237, 'lightning', 'el-icon-lightning', 'icon');
INSERT INTO `sys_dict` VALUES (238, 'heavy-rain', 'el-icon-heavy-rain', 'icon');
INSERT INTO `sys_dict` VALUES (239, 'sunrise', 'el-icon-sunrise', 'icon');
INSERT INTO `sys_dict` VALUES (240, 'sunrise-1', 'el-icon-sunrise-1', 'icon');
INSERT INTO `sys_dict` VALUES (241, 'sunset', 'el-icon-sunset', 'icon');
INSERT INTO `sys_dict` VALUES (242, 'sunny', 'el-icon-sunny', 'icon');
INSERT INTO `sys_dict` VALUES (243, 'cloudy', 'el-icon-cloudy', 'icon');
INSERT INTO `sys_dict` VALUES (244, 'partly-cloudy', 'el-icon-partly-cloudy', 'icon');
INSERT INTO `sys_dict` VALUES (245, 'cloudy-and-sunny', 'el-icon-cloudy-and-sunny', 'icon');
INSERT INTO `sys_dict` VALUES (246, 'moon', 'el-icon-moon', 'icon');
INSERT INTO `sys_dict` VALUES (247, 'moon-night', 'el-icon-moon-night', 'icon');
INSERT INTO `sys_dict` VALUES (248, 'dish', 'el-icon-dish', 'icon');
INSERT INTO `sys_dict` VALUES (249, 'dish-1', 'el-icon-dish-1', 'icon');
INSERT INTO `sys_dict` VALUES (250, 'food', 'el-icon-food', 'icon');
INSERT INTO `sys_dict` VALUES (251, 'chicken', 'el-icon-chicken', 'icon');
INSERT INTO `sys_dict` VALUES (252, 'fork-spoon', 'el-icon-fork-spoon', 'icon');
INSERT INTO `sys_dict` VALUES (253, 'knife-fork', 'el-icon-knife-fork', 'icon');
INSERT INTO `sys_dict` VALUES (254, 'burger', 'el-icon-burger', 'icon');
INSERT INTO `sys_dict` VALUES (255, 'tableware', 'el-icon-tableware', 'icon');
INSERT INTO `sys_dict` VALUES (256, 'sugar', 'el-icon-sugar', 'icon');
INSERT INTO `sys_dict` VALUES (257, 'dessert', 'el-icon-dessert', 'icon');
INSERT INTO `sys_dict` VALUES (258, 'ice-cream', 'el-icon-ice-cream', 'icon');
INSERT INTO `sys_dict` VALUES (259, 'hot-water', 'el-icon-hot-water', 'icon');
INSERT INTO `sys_dict` VALUES (260, 'water-cup', 'el-icon-water-cup', 'icon');
INSERT INTO `sys_dict` VALUES (261, 'coffee-cup', 'el-icon-coffee-cup', 'icon');
INSERT INTO `sys_dict` VALUES (262, 'cold-drink', 'el-icon-cold-drink', 'icon');
INSERT INTO `sys_dict` VALUES (263, 'goblet', 'el-icon-goblet', 'icon');
INSERT INTO `sys_dict` VALUES (264, 'goblet-full', 'el-icon-goblet-full', 'icon');
INSERT INTO `sys_dict` VALUES (265, 'goblet-square', 'el-icon-goblet-square', 'icon');
INSERT INTO `sys_dict` VALUES (266, 'goblet-square-full', 'el-icon-goblet-square-full', 'icon');
INSERT INTO `sys_dict` VALUES (267, 'refrigerator', 'el-icon-refrigerator', 'icon');
INSERT INTO `sys_dict` VALUES (268, 'grape', 'el-icon-grape', 'icon');
INSERT INTO `sys_dict` VALUES (269, 'watermelon', 'el-icon-watermelon', 'icon');
INSERT INTO `sys_dict` VALUES (270, 'cherry', 'el-icon-cherry', 'icon');
INSERT INTO `sys_dict` VALUES (271, 'apple', 'el-icon-apple', 'icon');
INSERT INTO `sys_dict` VALUES (272, 'pear', 'el-icon-pear', 'icon');
INSERT INTO `sys_dict` VALUES (273, 'orange', 'el-icon-orange', 'icon');
INSERT INTO `sys_dict` VALUES (274, 'ice-tea', 'el-icon-ice-tea', 'icon');
INSERT INTO `sys_dict` VALUES (275, 'ice-drink', 'el-icon-ice-drink', 'icon');
INSERT INTO `sys_dict` VALUES (276, 'milk-tea', 'el-icon-milk-tea', 'icon');
INSERT INTO `sys_dict` VALUES (277, 'potato-strips', 'el-icon-potato-strips', 'icon');
INSERT INTO `sys_dict` VALUES (278, 'lollipop', 'el-icon-lollipop', 'icon');
INSERT INTO `sys_dict` VALUES (279, 'ice-cream-square', 'el-icon-ice-cream-square', 'icon');
INSERT INTO `sys_dict` VALUES (280, 'ice-cream-round', 'el-icon-ice-cream-round', 'icon');

-- ----------------------------
-- Table structure for sys_file
-- ----------------------------
DROP TABLE IF EXISTS `sys_file`;
CREATE TABLE `sys_file`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文件名称',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文件类型',
  `size` bigint NULL DEFAULT NULL COMMENT '文件大小(kb)',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '下载链接',
  `md5` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '文件md5',
  `is_delete` tinyint(1) NULL DEFAULT 0 COMMENT '是否删除',
  `enable` tinyint(1) NULL DEFAULT 1 COMMENT '是否禁用链接',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 72 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_file
-- ----------------------------
INSERT INTO `sys_file` VALUES (1, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (2, '布偶猫.jpg', 'jpg', 355, 'http://localhost:9090/file/58452f19443341e98dd60f11cbb47de8.jpg', 'fd4c92869de9ae5096bb8c3b0092bf88', 0, 1);
INSERT INTO `sys_file` VALUES (3, '拉布拉多.jpeg', 'jpeg', 30, 'http://localhost:9090/file/26789e7fcbf04e31bb7066df0179a7c1.jpeg', 'e7dd5bbd01c0e23a87bc2e7dd33fa546', 0, 1);
INSERT INTO `sys_file` VALUES (4, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (5, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (6, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (7, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (8, '柯基.jpeg', 'jpeg', 37, 'http://localhost:9090/file/a983f2a0a32d4ada989447d61f7b0319.jpeg', '91685d0abc5e01cd9af69d8b05d2532e', 0, 1);
INSERT INTO `sys_file` VALUES (9, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (10, '伯曼猫.jpg', 'jpg', 420, 'http://localhost:9090/file/d2b60251dd6a4a808182dd49ecb146d7.jpg', '7ee6d56f92547af4d28201d3351291d0', 0, 1);
INSERT INTO `sys_file` VALUES (11, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (12, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (13, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (14, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (15, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (16, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (17, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (18, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (19, '拉布拉多.jpeg', 'jpeg', 30, 'http://localhost:9090/file/26789e7fcbf04e31bb7066df0179a7c1.jpeg', 'e7dd5bbd01c0e23a87bc2e7dd33fa546', 0, 1);
INSERT INTO `sys_file` VALUES (20, '金毛.jpeg', 'jpeg', 27, 'http://localhost:9090/file/3f36ac86d2954bf59cdcdea8635f5737.jpeg', '8c4815b2c6627afca6ad00a14bcfa4b9', 0, 1);
INSERT INTO `sys_file` VALUES (21, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);
INSERT INTO `sys_file` VALUES (22, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (23, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (24, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);
INSERT INTO `sys_file` VALUES (25, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (26, '拉布拉多.jpeg', 'jpeg', 30, 'http://localhost:9090/file/26789e7fcbf04e31bb7066df0179a7c1.jpeg', 'e7dd5bbd01c0e23a87bc2e7dd33fa546', 0, 1);
INSERT INTO `sys_file` VALUES (27, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);
INSERT INTO `sys_file` VALUES (28, '金毛.jpeg', 'jpeg', 27, 'http://localhost:9090/file/3f36ac86d2954bf59cdcdea8635f5737.jpeg', '8c4815b2c6627afca6ad00a14bcfa4b9', 0, 1);
INSERT INTO `sys_file` VALUES (29, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (30, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);
INSERT INTO `sys_file` VALUES (31, '拉布拉多.jpeg', 'jpeg', 30, 'http://localhost:9090/file/26789e7fcbf04e31bb7066df0179a7c1.jpeg', 'e7dd5bbd01c0e23a87bc2e7dd33fa546', 0, 1);
INSERT INTO `sys_file` VALUES (32, '土狗专用狗粮.jpg', 'jpg', 231, 'http://localhost:9090/file/4e7b142f235449a494e61888a1977783.jpg', 'fa6d187892c40a2429e9e8e887aa6b02', 0, 1);
INSERT INTO `sys_file` VALUES (33, '麦富迪狗粮.jpg', 'jpg', 294, 'http://localhost:9090/file/cd50639b7f474c68b0ac7d8422a8e05e.jpg', '807f9642d7d554ec66203251829048a7', 0, 1);
INSERT INTO `sys_file` VALUES (34, '卫仕猫多维.jpg', 'jpg', 178, 'http://localhost:9090/file/eeed0976658943639dbf52b0f6d5060b.jpg', 'a8805047a3ae9dce490962652c236198', 0, 1);
INSERT INTO `sys_file` VALUES (35, '卫仕 关节舒.jpg', 'jpg', 173, 'http://localhost:9090/file/c90dbdaddecf4a2c941c7e6259599a97.jpg', '5fd079f9c2d3b0b3a3e249892d9f7819', 0, 1);
INSERT INTO `sys_file` VALUES (36, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (37, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (38, '中华田园犬.jpeg', 'jpeg', 31, 'http://localhost:9090/file/74d69757a36a473993705a4f6047466c.jpeg', '829862bd99ad295cff8a3bd08d32bd1d', 0, 1);
INSERT INTO `sys_file` VALUES (39, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);
INSERT INTO `sys_file` VALUES (40, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);
INSERT INTO `sys_file` VALUES (41, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (42, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (43, '柯基.jpeg', 'jpeg', 37, 'http://localhost:9090/file/a983f2a0a32d4ada989447d61f7b0319.jpeg', '91685d0abc5e01cd9af69d8b05d2532e', 0, 1);
INSERT INTO `sys_file` VALUES (44, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (45, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);
INSERT INTO `sys_file` VALUES (46, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (47, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (48, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (49, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (50, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (51, '金毛.jpeg', 'jpeg', 27, 'http://localhost:9090/file/3f36ac86d2954bf59cdcdea8635f5737.jpeg', '8c4815b2c6627afca6ad00a14bcfa4b9', 0, 1);
INSERT INTO `sys_file` VALUES (52, '金毛.jpeg', 'jpeg', 27, 'http://localhost:9090/file/3f36ac86d2954bf59cdcdea8635f5737.jpeg', '8c4815b2c6627afca6ad00a14bcfa4b9', 0, 1);
INSERT INTO `sys_file` VALUES (53, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (54, '伯曼猫.jpg', 'jpg', 420, 'http://localhost:9090/file/d2b60251dd6a4a808182dd49ecb146d7.jpg', '7ee6d56f92547af4d28201d3351291d0', 0, 1);
INSERT INTO `sys_file` VALUES (55, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (56, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (57, '伯曼猫.jpg', 'jpg', 420, 'http://localhost:9090/file/d2b60251dd6a4a808182dd49ecb146d7.jpg', '7ee6d56f92547af4d28201d3351291d0', 0, 1);
INSERT INTO `sys_file` VALUES (58, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (59, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (60, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (61, '奥西猫.jpg', 'jpg', 647, 'http://localhost:9090/file/05bd1e6795b049f89ff632c4175cd9f2.jpg', 'e4481b03f527de1bcbbccd77bcb93276', 0, 1);
INSERT INTO `sys_file` VALUES (62, '金毛.jpeg', 'jpeg', 27, 'http://localhost:9090/file/3f36ac86d2954bf59cdcdea8635f5737.jpeg', '8c4815b2c6627afca6ad00a14bcfa4b9', 0, 1);
INSERT INTO `sys_file` VALUES (63, '金毛.jpeg', 'jpeg', 27, 'http://localhost:9090/file/3f36ac86d2954bf59cdcdea8635f5737.jpeg', '8c4815b2c6627afca6ad00a14bcfa4b9', 0, 1);
INSERT INTO `sys_file` VALUES (64, '柴犬.jpeg', 'jpeg', 26, 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'a683c38b280e623638fedb16add0bc2f', 0, 1);
INSERT INTO `sys_file` VALUES (65, '柯基.jpeg', 'jpeg', 37, 'http://localhost:9090/file/a983f2a0a32d4ada989447d61f7b0319.jpeg', '91685d0abc5e01cd9af69d8b05d2532e', 0, 1);
INSERT INTO `sys_file` VALUES (66, '拉布拉多.jpeg', 'jpeg', 30, 'http://localhost:9090/file/26789e7fcbf04e31bb7066df0179a7c1.jpeg', 'e7dd5bbd01c0e23a87bc2e7dd33fa546', 0, 1);
INSERT INTO `sys_file` VALUES (67, '柯基.jpeg', 'jpeg', 37, 'http://localhost:9090/file/a983f2a0a32d4ada989447d61f7b0319.jpeg', '91685d0abc5e01cd9af69d8b05d2532e', 0, 1);
INSERT INTO `sys_file` VALUES (68, '柯基.jpeg', 'jpeg', 37, 'http://localhost:9090/file/a983f2a0a32d4ada989447d61f7b0319.jpeg', '91685d0abc5e01cd9af69d8b05d2532e', 0, 1);
INSERT INTO `sys_file` VALUES (69, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);
INSERT INTO `sys_file` VALUES (70, '柯基.jpeg', 'jpeg', 37, 'http://localhost:9090/file/a983f2a0a32d4ada989447d61f7b0319.jpeg', '91685d0abc5e01cd9af69d8b05d2532e', 0, 1);
INSERT INTO `sys_file` VALUES (71, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);
INSERT INTO `sys_file` VALUES (72, '萨摩耶.jpeg', 'jpeg', 16, 'http://localhost:9090/file/d0dbd6e13bef406ca33d42167e19aafd.jpeg', '7e8d5be96e7de700d70d1061446aa069', 0, 1);

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '路径',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '图标',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '描述',
  `pid` int NULL DEFAULT NULL COMMENT '父级id',
  `page_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '页面路径',
  `sort_num` int NULL DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 27 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES (4, '系统管理', NULL, 'el-icon-s-grid', NULL, NULL, NULL, 300);
INSERT INTO `sys_menu` VALUES (5, '用户管理', '/user', 'el-icon-user', NULL, 4, 'User', 301);
INSERT INTO `sys_menu` VALUES (6, '角色管理', '/role', 'el-icon-s-custom', NULL, 4, 'Role', 302);
INSERT INTO `sys_menu` VALUES (7, '菜单管理', '/menu', 'el-icon-menu', NULL, 4, 'Menu', 303);
INSERT INTO `sys_menu` VALUES (10, '主页', '/home', 'el-icon-house', NULL, NULL, 'Home', 0);
INSERT INTO `sys_menu` VALUES (11, '公告管理', '/notice', 'el-icon-menu', NULL, NULL, 'Notice', 2);
INSERT INTO `sys_menu` VALUES (12, '图片管理', '/banner', 'el-icon-picture', NULL, NULL, 'Banner', 999);
INSERT INTO `sys_menu` VALUES (13, '课程管理', '/course', 'el-icon-menu', NULL, NULL, 'Course', 999);
INSERT INTO `sys_menu` VALUES (14, '试题管理', '/examQuestion', 'el-icon-menu', NULL, NULL, 'ExamQuestion', 999);
INSERT INTO `sys_menu` VALUES (15, '考试管理', '/exam', 'el-icon-menu', NULL, NULL, 'Exam', 999);
INSERT INTO `sys_menu` VALUES (16, '评分管理', '/score', 'el-icon-menu', NULL, NULL, 'Score', 999);
INSERT INTO `sys_menu` VALUES (17, '课程申请管理', '/apply', 'el-icon-tickets', NULL, NULL, 'Apply', 999);
INSERT INTO `sys_menu` VALUES (18, '评论信息管理', '/comment', 'el-icon-s-comment', NULL, NULL, 'Comment', 999);
INSERT INTO `sys_menu` VALUES (19, '评论管理', '/comments', 'el-icon-s-comment', NULL, NULL, 'Comments', 999);
INSERT INTO `sys_menu` VALUES (22, '资讯管理', '/consulting', 'el-icon-s-promotion', NULL, NULL, 'Consulting', 999);
INSERT INTO `sys_menu` VALUES (23, '教学管理', NULL, 'el-icon-menu', NULL, NULL, NULL, 400);
INSERT INTO `sys_menu` VALUES (24, '课程管理', '/course', NULL, NULL, 23, 'Course', 1);
INSERT INTO `sys_menu` VALUES (25, '试题管理', '/examQuestion', NULL, NULL, 23, 'ExamQuestion', 2);
INSERT INTO `sys_menu` VALUES (26, '考试管理', '/exam', NULL, NULL, 23, 'Exam', 3);
INSERT INTO `sys_menu` VALUES (27, '评分管理', '/score', NULL, NULL, 23, 'Score', 4);

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '描述',
  `flag` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '唯一标识',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '管理员', '管理员', 'ADMIN');
INSERT INTO `sys_role` VALUES (2, '普通用户', '普通用户', 'USER');
INSERT INTO `sys_role` VALUES (3, '教师', '管理学生', 'TEACHER');

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `role_id` int NOT NULL COMMENT '角色id',
  `menu_id` int NOT NULL COMMENT '菜单id',
  PRIMARY KEY (`role_id`, `menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '角色菜单关系表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES (1, 4);
INSERT INTO `sys_role_menu` VALUES (1, 5);
INSERT INTO `sys_role_menu` VALUES (1, 6);
INSERT INTO `sys_role_menu` VALUES (1, 7);
INSERT INTO `sys_role_menu` VALUES (1, 10);
INSERT INTO `sys_role_menu` VALUES (1, 11);
INSERT INTO `sys_role_menu` VALUES (1, 12);
INSERT INTO `sys_role_menu` VALUES (1, 17);
INSERT INTO `sys_role_menu` VALUES (1, 18);
INSERT INTO `sys_role_menu` VALUES (1, 22);
INSERT INTO `sys_role_menu` VALUES (1, 23);
INSERT INTO `sys_role_menu` VALUES (1, 24);
INSERT INTO `sys_role_menu` VALUES (1, 25);
INSERT INTO `sys_role_menu` VALUES (1, 26);
INSERT INTO `sys_role_menu` VALUES (1, 27);
INSERT INTO `sys_role_menu` VALUES (2, 10);
INSERT INTO `sys_role_menu` VALUES (3, 10);
INSERT INTO `sys_role_menu` VALUES (3, 17);
INSERT INTO `sys_role_menu` VALUES (3, 18);
INSERT INTO `sys_role_menu` VALUES (3, 22);
INSERT INTO `sys_role_menu` VALUES (3, 23);
INSERT INTO `sys_role_menu` VALUES (3, 24);
INSERT INTO `sys_role_menu` VALUES (3, 25);
INSERT INTO `sys_role_menu` VALUES (3, 26);
INSERT INTO `sys_role_menu` VALUES (3, 27);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '昵称',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '电话',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '地址',
  `create_time` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `avatar_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '头像',
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色',
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '性别',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'admin', 'admin', '管理员', 'admin@qq.com', '13988997788', '安徽合肥', '2024-04-15 21:10:27', 'http://localhost:9090/file/a2d2da19bde9429c96d2e627b0f03a64.jpg', 'ADMIN', NULL);
INSERT INTO `sys_user` VALUES (2, 'zhang', '123', '张张', 'zhang@qq.com', '13677889900', '南京', '2024-04-15 21:10:27', 'http://localhost:9090/file/6ae5d336e9ff4ab3a2014f6b423ab9d0.jpeg', 'USER', NULL);
INSERT INTO `sys_user` VALUES (3, 'wang', '123', '我是王五', 'wang@qq.com', '13111111111', '上海', '2024-04-15 21:10:27', 'http://localhost:9090/file/a2d2da19bde9429c96d2e627b0f03a64.jpg', 'USER', NULL);
INSERT INTO `sys_user` VALUES (4, 'root', '123', '王老师', '443201@.com', '13111111111', '湖北宜昌三峡大坝', '2024-09-09 15:20:07', NULL, 'TEACHER', '男');
INSERT INTO `sys_user` VALUES (5, 'test', '123', '李老师', '443201@.com', '13111111111', '湖北武汉', '2024-09-09 17:36:27', NULL, 'TEACHER', NULL);
INSERT INTO `sys_user` VALUES (6, 'user', '123', '李老师', '443201@.com', '13111111111', NULL, '2024-09-14 20:51:21', NULL, 'TEACHER', NULL);
INSERT INTO `sys_user` VALUES (7, '123', '123', '小王', '443201', '15111111111', NULL, '2024-09-14 22:01:18', 'http://localhost:9090/file/a983f2a0a32d4ada989447d61f7b0319.jpeg', 'USER', '男');

SET FOREIGN_KEY_CHECKS = 1;
