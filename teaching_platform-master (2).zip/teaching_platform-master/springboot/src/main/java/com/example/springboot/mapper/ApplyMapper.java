package com.example.springboot.mapper;

import com.example.springboot.entity.Apply;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 申请审批表 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-09-10
 */
public interface ApplyMapper extends BaseMapper<Apply> {

}
