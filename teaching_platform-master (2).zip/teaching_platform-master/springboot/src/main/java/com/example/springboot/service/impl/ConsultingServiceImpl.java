package com.example.springboot.service.impl;

import com.example.springboot.entity.Consulting;
import com.example.springboot.mapper.ConsultingMapper;
import com.example.springboot.service.IConsultingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 资讯信息表 服务实现类
 * </p>
 */
@Service
public class ConsultingServiceImpl extends ServiceImpl<ConsultingMapper, Consulting> implements IConsultingService {

}
