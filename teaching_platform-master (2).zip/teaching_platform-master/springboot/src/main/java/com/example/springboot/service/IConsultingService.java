package com.example.springboot.service;

import com.example.springboot.entity.Consulting;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 资讯信息表 服务类
 * </p>
 */
public interface IConsultingService extends IService<Consulting> {

}
