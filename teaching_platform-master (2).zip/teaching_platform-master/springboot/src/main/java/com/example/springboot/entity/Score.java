package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 */
@Getter
@Setter
@ApiModel(value = "Score对象", description = "")
public class Score implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("用户id")
    private Integer userId;

    @ApiModelProperty("考试id")
    private Integer examId;

    @ApiModelProperty("老师id")
    private Integer teacherId;

    @ApiModelProperty("分数")
    private Integer score;

    @ApiModelProperty("用户答案")
    private String userAnswers;

    @ApiModelProperty("考试名称")
    private String name;

    @ApiModelProperty("题目ids")
    private String ids;

    @ApiModelProperty("是否评分")
    private String isScore;

    @TableField(exist = false)
    private String user;
}
