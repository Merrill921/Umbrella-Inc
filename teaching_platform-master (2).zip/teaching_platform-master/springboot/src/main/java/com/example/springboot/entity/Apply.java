package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 申请审批表
 * </p>
 */
@Getter
@Setter
@ApiModel(value = "Apply对象", description = "申请审批表")
public class Apply implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("学生ID")
    private Integer userId;

    @ApiModelProperty("课程ID")
    private Integer courseId;

    @ApiModelProperty("申请说明")
    private String description;

    @ApiModelProperty("当前进度")
    private String process;

    @ApiModelProperty("审核状态")
    private String status;

    @ApiModelProperty("审核说明")
    private String note;

    @TableField(exist = false)
    private String user;

    @TableField(exist = false)
    private String courseName;
}
