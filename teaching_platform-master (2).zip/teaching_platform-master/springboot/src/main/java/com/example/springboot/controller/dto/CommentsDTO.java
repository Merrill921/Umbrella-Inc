package com.example.springboot.controller.dto;
import com.example.springboot.entity.Comments;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

@Data
public class CommentsDTO {
    /**  */
    private Integer id;
    /** 内容 */
    private String content;
    /** 用户名称 */
    private String username;
    /** 用户id */
    private Integer userId;
    /** 评分 */
    private BigDecimal rate;
    /** 业务模块的id */
    private Integer foreignId;
    /** 父级评论id */
    private Integer pid;
    /** 回复对象 */
    private String target;

    public List<Comments> children;

    @ApiModelProperty("创建时间")
    private String time;

    @ApiModelProperty("用户头像")
    private String img;
}
