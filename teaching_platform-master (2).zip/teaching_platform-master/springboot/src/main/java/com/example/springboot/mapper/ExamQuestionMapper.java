package com.example.springboot.mapper;

import com.example.springboot.entity.ExamQuestion;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 试题信息表 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-09-09
 */
public interface ExamQuestionMapper extends BaseMapper<ExamQuestion> {

}
