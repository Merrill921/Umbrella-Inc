package com.example.springboot.service.impl;

import com.example.springboot.entity.ExamQuestion;
import com.example.springboot.mapper.ExamQuestionMapper;
import com.example.springboot.service.IExamQuestionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 试题信息表 服务实现类
 * </p>
 */
@Service
public class ExamQuestionServiceImpl extends ServiceImpl<ExamQuestionMapper, ExamQuestion> implements IExamQuestionService {

}
