package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 试题信息表
 * </p>
 */
@Getter
@Setter
@TableName("exam_question")
@ApiModel(value = "ExamQuestion对象", description = "试题信息表")
public class ExamQuestion implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("题目")
    private String name;

    @ApiModelProperty("题型")
    private String type;

    @ApiModelProperty("选择题选项")
    private String options;

    @ApiModelProperty("正确答案")
    private String answer;

    @ApiModelProperty("分值")
    private Integer score;

    @ApiModelProperty("用户ID")
    private Integer userId;


}
