package com.example.springboot.mapper;

import com.example.springboot.entity.Banner;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-09-09
 */
public interface BannerMapper extends BaseMapper<Banner> {

}
