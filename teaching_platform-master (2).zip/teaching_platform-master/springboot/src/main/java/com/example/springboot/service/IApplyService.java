package com.example.springboot.service;

import com.example.springboot.entity.Apply;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 申请审批表 服务类
 * </p>
 */
public interface IApplyService extends IService<Apply> {

}
