package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 评论信息表
 * </p>
 */
@Getter
@Setter
@ApiModel(value = "Comment对象", description = "评论信息表")
public class Comment implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("学生ID")
    private Integer userId;

    @ApiModelProperty("课程ID")
    private Integer courseId;

    @ApiModelProperty("评论时间")
    private String time;

    @ApiModelProperty("评论内容")
    private String content;

    @ApiModelProperty("父ID")
    private Integer parentId;

    @TableField(exist = false)
    private String courseName;

    @TableField(exist = false)
    private String user;

    @TableField(exist = false)
    private String userAvatar;

    @TableField(exist = false)
    private List<Comment> children;
}
