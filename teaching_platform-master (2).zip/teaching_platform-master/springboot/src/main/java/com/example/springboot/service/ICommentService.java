package com.example.springboot.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.Comment;

import java.util.List;

/**
 * <p>
 * 评论信息表 服务类
 * </p>
 */
public interface ICommentService extends IService<Comment> {

    List<Comment> selectAll(Comment comment);

}
