package com.example.springboot.service.impl;

import com.example.springboot.entity.Apply;
import com.example.springboot.mapper.ApplyMapper;
import com.example.springboot.service.IApplyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 申请审批表 服务实现类
 * </p>
 */
@Service
public class ApplyServiceImpl extends ServiceImpl<ApplyMapper, Apply> implements IApplyService {

}
