package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.math.BigInteger;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 课程管理
 * </p>
 */
@Getter
@Setter
@ApiModel(value = "Course对象", description = "课程管理")
public class Course implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("课程名称")
    private String name;

    @ApiModelProperty("课程图片")
    private String img;

    @ApiModelProperty("课程描述")
    private String describes;

    @ApiModelProperty("课程类型")
    private String type;

    @ApiModelProperty("授课教师id")
    private Integer teacherId;

    @ApiModelProperty("数量")
    private BigInteger num;

    @ApiModelProperty("学生id")
    private Integer userId;

    @TableField(exist = false)
    private String teacherName;
    @TableField(exist = false)
    private String username;
}
