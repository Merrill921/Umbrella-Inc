package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 资讯信息表
 * </p>
 */
@Getter
@Setter
@ApiModel(value = "Consulting对象", description = "资讯信息表")
public class Consulting implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("标题名称")
    private String name;

    @ApiModelProperty("图片")
    private String img;

    @ApiModelProperty("内容")
    private String content;

    @ApiModelProperty("发布时间")
    private String createTime;

    @ApiModelProperty("发布人")
    private Integer userId;


    @TableField(exist = false)
    private String user;
}
