package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 讨论信息表
 * </p>
 */
@Getter
@Setter
@ApiModel(value = "Comments对象", description = "讨论信息表")
public class Comments implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("内容")
    private String content;

    @ApiModelProperty("用户名称")
    private String username;

    @ApiModelProperty("用户id")
    private Integer userId;

    @ApiModelProperty("评分")
    private BigDecimal rate;

    @ApiModelProperty("业务模块的id")
    private Integer foreignId;

    @ApiModelProperty("父级评论id")
    private Integer pid;

    @ApiModelProperty("回复对象")
    private String target;

    @ApiModelProperty("用户头像")
    private String img;

    @ApiModelProperty("创建时间")
    private String time;

    @TableField(exist = false)
    public List<Comments> children;
}
