package com.example.springboot.mapper;

import com.example.springboot.entity.Consulting;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 资讯信息表 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-09-12
 */
public interface ConsultingMapper extends BaseMapper<Consulting> {

}
