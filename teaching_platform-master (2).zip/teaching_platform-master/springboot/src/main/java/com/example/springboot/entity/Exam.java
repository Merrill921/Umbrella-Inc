package com.example.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.Date;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 考试信息管理
 * </p>
 */
@Getter
@Setter
@ApiModel(value = "Exam对象", description = "考试信息管理")
public class Exam implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("封面图")
    private String img;

    @ApiModelProperty("开始时间")
    private String startTime;

    @ApiModelProperty("结束时间")
    private String endTime;

    @ApiModelProperty("试题列表")
    private String question;

    @ApiModelProperty("考试总分")
    private Integer score;

    @ApiModelProperty("用户id")
    private Integer userId;

    @ApiModelProperty("考试标题")
    private String name;

    @TableField(exist = false)
    private String isExam;

    @TableField(exist = false)
    private String user;
}
