package com.example.springboot.mapper;

import com.example.springboot.entity.Exam;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 考试信息管理 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-09-09
 */
public interface ExamMapper extends BaseMapper<Exam> {

}
