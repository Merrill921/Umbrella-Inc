package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.Comment;
import com.example.springboot.mapper.CommentMapper;
import com.example.springboot.service.ICommentService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;


/**
 * <p>
 * 评论信息表 服务实现类
 * </p>
 */
@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements ICommentService {

    @Resource
    private CommentMapper commentMapper;

    @Override
    public List<Comment> selectAll(Comment comment) {

        comment.setParentId(0);
        List<Comment> comments = commentMapper.selectAll(comment);
        for (Comment dbComment : comments) {
            comment.setParentId(dbComment.getId());
            List<Comment> children  = commentMapper.selectAll(comment);
            dbComment.setChildren(children);
        }
        return comments;
    }
}
