package com.example.springboot.controller;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelWriter;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletOutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.springboot.entity.Course;
import com.example.springboot.mapper.CommentMapper;
import com.example.springboot.service.ICourseService;
import com.example.springboot.service.IUserService;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.springboot.common.Result;
import org.springframework.web.multipart.MultipartFile;
import com.example.springboot.entity.User;
import com.example.springboot.utils.TokenUtils;

import com.example.springboot.service.ICommentService;
import com.example.springboot.entity.Comment;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 评论信息表 前端控制器
 * </p>
 */
@RestController
@RequestMapping("/comment")
public class CommentController {

    @Resource
    private ICommentService commentService;

    @Resource
    private IUserService userService;

    @Resource
    private ICourseService courseService;

    @Resource
    private CommentMapper commentMapper;

    private final String now = DateUtil.now();

    // 新增或者更新
    @PostMapping
    public Result save(@RequestBody Comment comment) {
        if (comment.getId() == null) {
            comment.setTime(DateUtil.now());
            //comment.setUser(TokenUtils.getCurrentUser().getUsername());
        }
        commentService.saveOrUpdate(comment);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        commentService.removeById(id);
        return Result.success();
    }

    @PostMapping("/del/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        commentService.removeByIds(ids);
        return Result.success();
    }

//    @GetMapping("/list")
//    public Result list(@RequestParam Integer foreignId) {
//        Map<String, Object> map = new HashMap<>();
//
//        LambdaQueryWrapper<Comment> wrapper = new LambdaQueryWrapper<>();
//        wrapper.eq(Comment::getForeignId,foreignId);
//        List<Comment> comments = commentService.list(wrapper);
//        map.put("rate", BigDecimal.ZERO);
//        List<Comment> commentList = comments.stream().filter(comment -> comment.getRate() != null).collect(Collectors.toList());
//        commentList.stream().map(Comment::getRate).reduce(BigDecimal::add).ifPresent(res -> {
//            map.put("rate", res.divide(BigDecimal.valueOf(commentList.size()), 1, RoundingMode.HALF_UP));
//        });
//
//        List<Comment> rootComments = comments.stream().filter(comment -> comment.getPid() == null).collect(Collectors.toList());
//
//        ArrayList<Object> objects = new ArrayList<>();
//
//        for (Comment rootComment : rootComments) {
//            CommentDTO commentDTO = new CommentDTO();
//            BeanUtils.copyProperties(rootComment,commentDTO);
//            commentDTO.setChildren(comments.stream().filter(comment -> rootComment.getId().equals(comment.getPid())).collect(Collectors.toList()));
//            objects.add(commentDTO);
//        }
//        map.put("comments", objects);
//        return Result.success(map);
//    }

    @GetMapping("/selectAll")
    public Result selectAll(Comment comment) {
        List<Comment> list = commentService.selectAll(comment);
        return Result.success(list);
    }

    @GetMapping
    public Result findAll() {
        List<Comment> list = commentService.list();
        list.forEach(v -> {
            User user = userService.getById(v.getUserId());
            if (ObjectUtil.isNotEmpty(user)){
                v.setUser(user.getUsername());
                v.setUserAvatar(user.getAvatarUrl());
            }

            Course course = courseService.getById(v.getCourseId());
            if (ObjectUtil.isNotEmpty(course)){
                v.setCourseName(course.getName());
            }
        });
        return Result.success(list);
    }

    @GetMapping("/{id}")
    public Result findOne(@PathVariable Integer id) {
        return Result.success(commentService.getById(id));
    }

    @GetMapping("/page")
    public Result findPage(@RequestParam(defaultValue = "") String content,
                           @RequestParam Integer pageNum,
                           @RequestParam Integer pageSize) {
        QueryWrapper<Comment> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("id");
        if (!"".equals(content)) {
            queryWrapper.like("content", content);
        }
//        User currentUser = TokenUtils.getCurrentUser();
//        if (currentUser.getRole().equals("USER")) {
//            queryWrapper.eq("user", currentUser.getUsername());
//        }
        Page<Comment> page = commentService.page(new Page<>(pageNum, pageSize), queryWrapper);
        page.getRecords().forEach(record -> {
            User user = userService.getById(record.getUserId());
            if (ObjectUtil.isNotEmpty(user)){
                record.setUser(user.getUsername());
            }

            Course course = courseService.getById(record.getCourseId());
            if (ObjectUtil.isNotEmpty(course)){
                record.setCourseName(course.getName());
            }
        });


        return Result.success(page);
    }

    /**
    * 导出接口
    */
    @GetMapping("/export")
    public void export(HttpServletResponse response) throws Exception {
        // 从数据库查询出所有的数据
        List<Comment> list = commentService.list();
        // 在内存操作，写出到浏览器
        ExcelWriter writer = ExcelUtil.getWriter(true);

        // 一次性写出list内的对象到excel，使用默认样式，强制输出标题
        writer.write(list, true);

        // 设置浏览器响应的格式
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        String fileName = URLEncoder.encode("Comment信息表", "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ".xlsx");

        ServletOutputStream out = response.getOutputStream();
        writer.flush(out, true);
        out.close();
        writer.close();

        }

    /**
     * excel 导入
     * @param file
     * @throws Exception
     */
    @PostMapping("/import")
    public Result imp(MultipartFile file) throws Exception {
        InputStream inputStream = file.getInputStream();
        ExcelReader reader = ExcelUtil.getReader(inputStream);
        // 通过 javabean的方式读取Excel内的对象，但是要求表头必须是英文，跟javabean的属性要对应起来
        List<Comment> list = reader.readAll(Comment.class);

        commentService.saveBatch(list);
        return Result.success();
    }

    private User getUser() {
        return TokenUtils.getCurrentUser();
    }

}

