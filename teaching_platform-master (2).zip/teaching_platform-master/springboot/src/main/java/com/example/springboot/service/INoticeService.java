package com.example.springboot.service;

import com.example.springboot.entity.Notice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 公告信息表 服务类
 * </p>
 */
public interface INoticeService extends IService<Notice> {

}
