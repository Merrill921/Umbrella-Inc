package com.example.springboot.service;

import com.example.springboot.entity.Course;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程管理 服务类
 * </p>
 */
public interface ICourseService extends IService<Course> {

}
