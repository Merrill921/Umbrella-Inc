package com.example.springboot.service;

import com.example.springboot.entity.Comments;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 讨论信息表 服务类
 * </p>
 */
public interface ICommentsService extends IService<Comments> {

}
