package com.example.springboot.mapper;

import com.example.springboot.entity.Course;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 课程管理 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-09-09
 */
public interface CourseMapper extends BaseMapper<Course> {

}
