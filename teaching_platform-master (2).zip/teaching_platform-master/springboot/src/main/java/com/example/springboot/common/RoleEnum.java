package com.example.springboot.common;

public enum RoleEnum {
    ADMIN, USER, TEACHER;
}
