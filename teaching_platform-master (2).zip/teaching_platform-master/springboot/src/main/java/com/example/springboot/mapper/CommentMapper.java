package com.example.springboot.mapper;

import com.example.springboot.entity.Comment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 评论信息表 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-09-10
 */
public interface CommentMapper extends BaseMapper<Comment> {

    List<Comment> selectAll(Comment comment);

}
