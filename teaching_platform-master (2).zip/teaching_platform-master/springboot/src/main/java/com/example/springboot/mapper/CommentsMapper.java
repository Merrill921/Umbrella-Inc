package com.example.springboot.mapper;

import com.example.springboot.entity.Comments;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 讨论信息表 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-09-10
 */
public interface CommentsMapper extends BaseMapper<Comments> {

}
