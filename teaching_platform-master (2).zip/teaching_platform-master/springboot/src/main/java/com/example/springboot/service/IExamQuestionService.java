package com.example.springboot.service;

import com.example.springboot.entity.ExamQuestion;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 试题信息表 服务类
 * </p>
 */
public interface IExamQuestionService extends IService<ExamQuestion> {

}
