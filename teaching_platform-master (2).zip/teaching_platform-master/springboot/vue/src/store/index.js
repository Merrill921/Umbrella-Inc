import Vue from 'vue'
import Vuex from 'vuex'
import router, {resetRouter} from "@/router";
import settings from './modules/settings'; // 导入settings模块
Vue.use(Vuex)

const store = new Vuex.Store({
    state: {
        currentPathName: ''
    },
    mutations: {
        setPath (state) {
            state.currentPathName = localStorage.getItem("currentPathName")
        },
        logout() {
            // 清空缓存
            localStorage.removeItem("user")
            localStorage.removeItem("menus")
            router.push("/login")
            // 重置路由
            resetRouter()
        }
    },
    modules: {
        settings // 注册settings模块，现在可以通过this.$store访问该模块
    }
})

export default store
