<template>
  <div style="color: #666;font-size: 14px;">
    <div style="padding-bottom: 20px">
      <b>您好！{{ user.nickname }}</b>
    </div>
    <el-card>
      欢迎使用本系统
    </el-card>
    <el-divider/>

    <el-card>
      <h3>系统公告</h3>

      <el-collapse>
        <el-collapse-item :title="item.name" :name="item.id" v-for="item in noticeList" :key="item.id">
          <div>发布时间：{{ item.time }}</div>
          <div>{{ item.content }}</div>
        </el-collapse-item>
      </el-collapse>
    </el-card>


  </div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      noticeList: []
    }
  },
  created() {
    this.getList()
  },
  mounted() {
    if (this.user.role === 'USER') {
      this.$router.push('/login')
    }
  },
  methods: {
    getList() {
      this.request.get("/notice").then(res => {
        if (res.code === '200') {
          this.noticeList = res.data
          console.log(res)
        } else {
        }
      })
    },

  }
}
</script>
