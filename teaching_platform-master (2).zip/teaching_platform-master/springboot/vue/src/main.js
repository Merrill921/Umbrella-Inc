import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import './assets/gloable.css'
import request from "@/utils/request";

// import '@/assets/styles/theme/index.css'
// import '@/assets/theme/index.scss'
// import '@/assets/styles/link-variables.scss'
import '@/element-style/index.css'
Vue.config.productionTip = false

import CustomEditor from "@/components/CustomEditor";
Vue.component("CustomEditor",CustomEditor)


import VideoPlayer from 'vue-video-player'
require('video.js/dist/video-js.css')
require('vue-video-player/src/custom-theme.css')
//全局引入
Vue.use(VideoPlayer)


Vue.use(ElementUI, { size: "mini" });

Vue.prototype.request=request

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
